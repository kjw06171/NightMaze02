Thank you for choosing Kokoro Reflections tile sets!

See terms at https://kokororeflections.com/terms-use/

Enjoy your new tiles!  If you need anything, head over to kokororeflections.com and get in touch.

Best,
M & T
Kokoro Reflections